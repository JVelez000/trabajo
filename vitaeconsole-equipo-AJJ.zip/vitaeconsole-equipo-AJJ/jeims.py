from hojasdevida import *

def update_cv():
    global data

    if not data:
        message_warning("⚠ No hay usuarios registrados.")
        return

    print("\n=== Lista de usuarios registrados ===")
    for user_id, user in data.items():
        print(f"{user_id} ==> {user['name']}")

    while True:
        user_id = input("\nIngresa el ID del usuario que deseas modificar: ")
        if user_id in data:
            break
        else:
            message_danger("❌ ID no encontrado. Intenta de nuevo.")

    while True:
        print(f"\n=== Actualizando el CV de {data[user_id]['name']} ===")
        print("1. Actualizar formación académica")
        print("2. Añadir experiencia laboral")
        print("3. Añadir referencia personal")
        print("4. Añadir habilidad o certificación")
        print("5. Volver al menú principal")

        option = input("Selecciona una opción (1-5): ")

        if option == "1":
            academic_data(user_id)
        elif option == "2":
            add_experience(user_id)
        elif option == "3":
            personal_references(user_id)
        elif option == "4":
            skills_certifications(user_id)
        elif option == "5":
            message_success("✔ Regresando al menú principal.")
            break
        else:
            message_warning("⚠ Opción no válida. Intenta de nuevo.")