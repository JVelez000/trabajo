

# def academic_data(user_id):
#     global data

#     while True:
#         institution = input_texto("Agregue la universidad: ")
#         if validate_str(institution):
#             break
#         else:
#             message_danger("❌ Ingresa un valor válido para la institución.")

#     while True:
#         title = input_texto("Título académico: ")
#         if validate_str(title):
#             break
#         else:
#             message_danger("❌ Ingresa un valor válido para el título.")

#     while True:
#         duration = input_numero("¿En qué año se graduó?: ")
#         if validate_date(duration):
#             break
#         else:
#             message_danger("❌ Ingresa un año válido (ej. 2022).")

#     data[user_id]["academic"] = {
#         "institution": institution,
#         "title": title,
#         "duration": duration
#     }
#     save_data()
#     message_success("✔️ Datos académicos agregados correctamente.")

# def add_experience(user_id):
#     global data

#     company = input_alphanumeric("Nombre de la empresa: ")
#     position = input_texto("Cargo ocupado: ")
#     functions = input_texto("Funciones del cargo: ")

#     while True:
#         duration = input_numero("Duración en la empresa (en años o meses): ")
#         if duration.isdigit() and int(duration) > 0:
#             break
#         else:
#             message_danger("❌ Solo se permiten números positivos.")

#     data[user_id]["experience"] = {
#         "company": company,
#         "position": position,
#         "functions": functions,
#         "duration": duration
#     }

#     save_data()
#     message_success("✔️ Experiencia laboral agregada correctamente.")

# def personal_references(user_id):
#     global data
#     while True:
#         ref = {
#             "name": input_texto("Nombre de la referencia personal: "),
#             "relation": input_texto("Relación con la referencia: "),
#             "contact": input_numero("Contacto de la referencia: ")
#         }
#         data[user_id]["references"].append(ref)
#         break

#     save_data()
#     message_success("✔️ Referencia personal agregada correctamente.")

# def skills_certifications(user_id):
#     global data

#     skill_certification = {
#         "skill_or_certification": input_texto("Habilidad o certificación: ")
#     }
#     data[user_id]["skills_certifications"].append(skill_certification)
#     save_data()
#     message_success("✔️ Habilidad o certificación agregada correctamente.")


#Filtrar por años de experiencia, formación o habilidades (Juan)




def big_filter():
    while True:
        print("\n¿Cómo deseas filtrar las hojas de vida?")
        print("1. Años de experiencia")
        print("2. Formación académica")
        print("3. Habilidades o certificaciones")
        print("4. Salir del filtro")

        try:
            choose = int(input("Selecciona una opción (1-4): "))
        except ValueError:
            message_danger("❌ Ingresa un número válido.")
            continue

        if choose == 1:
            try:
                yx = int(input("¿A partir de cuántos meses de experiencia deseas filtrar?: "))
            except ValueError:
                message_danger("❌ Ingresa un número válido.")
                continue

            print("\nLista de candidatos elegibles por experiencia:")
            count = 0
            for id, usuario in data.items():
                experiencia = usuario.get("experience", {})
                duracion = experiencia.get("duration")

                if duracion and duracion.isdigit() and int(duracion) >= yx:
                    count += 1
                    print(f"{count}. {usuario['name']} - {duracion} meses de experiencia")

            if count == 0:
                message_warning("⚠ No se encontraron candidatos con esa experiencia.")
        
        elif choose == 2:
            # Puedes implementar filtro por formación si lo necesitas aquí
            message_warning("⚠ Filtro por formación aún no implementado.")
        
        elif choose == 3:
            # Puedes implementar filtro por habilidades/certificaciones
            message_warning("⚠ Filtro por habilidades aún no implementado.")
        
        elif choose == 4:
            break
        else:
            message_danger("❌ Opción no válida. Intenta de nuevo.")