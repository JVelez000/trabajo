# Buscar por nombre, documento o correo electrónico (Angelica)
option = input("Ingresa la opción por la cual quieres buscar: [N] nombre, [I] id, [E] email").upper()

def search_by_name(name):
    name = input("Ingresa el nombre del usuario que deseas ingresar")
    for i, person in data.items():
        if name in person:
            print(f'''
            {person[name]},
            {person['contact']},
            {person['address']},
            {person['email']},
            {person['date']},
            {person['references']['name']},
            {person['references']['relation']},
            {person['references']['contact']},
            {person['skills_certifications']['skill_or_certification']},
            {person['academic']['institution']},
            {person['academic']['title']},
            {person['academic']['duration']},
            {person['experience']['company']},
            {person['experience']['position']},
            {person['experience']['functions']},
            {person['experience']['duration']},
            ''')
        else:
            print("No se encontró el usuario en la base de datos")

def search_by_id(id):
    id = input("Ingresa el id del usuario que deseas ingresar")
    if id in data:
        print(f'''
        {id['name']},
        {id['contact']},
        {id['address']},
        {id['email']},
        {id['date']},
        {id['references']['name']},
        {id['references']['relation']},
        {id['references']['contact']},
        {id['skills_certifications']['skill_or_certification']},
        {id['academic']['institution']},
        {id['academic']['title']},
        {id['academic']['duration']},
        {id['experience']['company']},
        {id['experience']['position']},
        {id['experience']['functions']},
        {id['experience']['duration']},
        ''')
    else:
        input("No se encontró el id en la base de datos")

def search_by_email(email):
    email = input("Ingresa el nombre del usuario que deseas ingresar")
    for i, person in data.items():
        if email in person:
            print(f'''
            {person['name']},
            {person['contact']},
            {person['address']},
            {person['date']},
            {person['references']['name']},
            {person['references']['relation']},
            {person['references']['contact']},
            {person['skills_certifications']['skill_or_certification']},
            {person['academic']['institution']},
            {person['academic']['title']},
            {person['academic']['duration']},
            {person['experience']['company']},
            {person['experience']['position']},
            {person['experience']['functions']},
            {person['experience']['duration']},
            ''')
        else:
            input("No se encontró el usuario en la base de datos")

match option:
    case 'N' | 'n': search_by_name(name) 
    case 'I' | 'i': search_by_id(id)
    case 'E' | 'e': search_by_email(email)





