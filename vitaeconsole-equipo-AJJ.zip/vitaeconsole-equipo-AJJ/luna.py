#• Visualizar en formato legible cada sección por separado o en conjunto (Luna)
#buscar y mostrar


    # import os
    # import re

    # def buscar_en_archivo(ruta_archivo, termino):
    #     try:
    #         with open(ruta_archivo, 'r') as archivo:
    #             contenido = archivo.read()
    #         if re.search(termino, contenido):
    #             return True  # Encontrado
    #         else:
    #             return False  # No encontrado
    #     except FileNotFoundError:
    #         print(f"Archivo no encontrado: {ruta_archivo}")
    #         return False

    # ruta_archivo = 'ejemplo.txt'
    # termino_busqueda = 'palabra_clave'
    # if buscar_en_archivo(ruta_archivo, termino_busqueda):
    #     print(f"El término '{termino_busqueda}' fue encontrado en {ruta_archivo}")
    # else:
    #     print(f"El término '{termino_busqueda}' no fue encontrado en {ruta_archivo}")
    
     #from hojasdevida import *
def search():
    while True:
        try: 
            with open(user_id,'r'):
                user_id= hojasdevida()
            if search(user_id):
                return True
            else:
        