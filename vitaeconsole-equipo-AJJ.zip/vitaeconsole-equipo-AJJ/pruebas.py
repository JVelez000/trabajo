from hojasdevida import *

def consult_cv():